-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 01:13 PM
-- Server version: 5.7.17-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leave_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `leaves_applied`
--

CREATE TABLE `leaves_applied` (
  `leave_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `backup_employee_id` int(11) NOT NULL,
  `reason` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `leaves_applied`
--

INSERT INTO `leaves_applied` (`leave_id`, `employee_id`, `from_date`, `to_date`, `backup_employee_id`, `reason`) VALUES
(1, 2, '2018-11-30', '2018-11-30', 3, 'Personal leave'),
(2, 2, '2018-12-01', '2018-12-02', 3, 'Casual leave'),
(3, 3, '2018-12-10', '2018-12-10', 2, 'Sick leave');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_password` text NOT NULL,
  `user_full_name` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`user_id`, `user_name`, `user_password`, `user_full_name`, `user_email`, `user_role`) VALUES
(1, 'superadmin', '4b78e581bdaffa037a6b11d58bdc934a', 'Super admin', 'admin@admin.com', 1),
(2, 'rahul', '2341fe77cfeb2f365d805bacc7440ddd', 'Rahul K', 'rahulkrishnak@gmail.com', 3),
(3, 'roshan', '4534344e975e9af0132fcad81a550b27', 'Roshan R', 'roshan@yahoo.com', 3),
(4, 'admin', '4b78e581bdaffa037a6b11d58bdc934a', 'Admin', 'admin1@admin.com', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leaves_applied`
--
ALTER TABLE `leaves_applied`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leaves_applied`
--
ALTER TABLE `leaves_applied`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
