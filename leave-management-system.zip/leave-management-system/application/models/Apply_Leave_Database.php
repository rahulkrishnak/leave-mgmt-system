<?php

Class Apply_Leave_Database extends CI_Model {

	// Select employees other than logged in employee from database
	public function read_employees($employeeId) {
	
		// Query to check whether username already exist or not
		$condition = "user_role = 3 AND user_id != '".$employeeId."'";
		$this->db->select('user_id, user_full_name, user_email');
		$this->db->from('user_login');
		$this->db->where($condition);
		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} 
		else {
			return false;
		}
	}
	
	// Function to apply leave
	public function leaves_insert($data) {		
		//$condition = "user_name =" . "'" . $data['user_name'] . "'";
		//$this->db->select('*');
		//$this->db->from('user_login');
		//$this->db->where($condition);
		//$this->db->limit(1);
		//$query = $this->db->get();
		//if ($query->num_rows() == 0) {
		
			// Query to insert data in database
			$this->db->insert('leaves_applied', $data);
			if ($this->db->affected_rows() > 0) {
				return true;
			}
		//} 
		//else {
		//	return false;
		//}
	}
	
	public function list_leaves($limit, $start) {	
		$this->db->limit($limit, $start);
		$this->db->select('`from_date`,`to_date`,`reason`,u.user_full_name AS employeeName,b.user_full_name AS backupEmployeeName');
		$this->db->from('leaves_applied l');
		$this->db->join('user_login u','u.user_id = l.employee_id');
		$this->db->join('user_login b','b.user_id = l.backup_employee_id');
		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} 
		else {
			return false;
		}
	}
}

?>