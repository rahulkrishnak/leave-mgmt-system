<?php

Class Add_User_Database extends CI_Model {

	// Insert user data in database
	public function registration_insert($data) {
	
		// Query to check whether username already exist or not
		$condition = "user_name =" . "'" . $data['user_name'] . "'";
		$this->db->select('*');
		$this->db->from('user_login');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 0) {
		
			// Query to insert data in database
			$this->db->insert('user_login', $data);
			if ($this->db->affected_rows() > 0) {
				return true;
			}
		} 
		else {
			return false;
		}
	}
	
	public function list_users() {
		$condition = "user_role != 1";
		$this->db->select('*');
		$this->db->from('user_login');
		$this->db->where($condition);
		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		} 
		else {
			return false;
		}
	}

}

?>