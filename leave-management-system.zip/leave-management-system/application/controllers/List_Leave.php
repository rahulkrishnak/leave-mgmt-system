<?php

Class List_Leave extends CI_Controller {
	
	public function __construct() {
		parent::__construct();		
		
		// Load session library
		$this->load->library('session');
		
		// Load database
		$this->load->model('apply_leave_database');
	}
	
	// Show list leave page
	public function index() {
		$leavesResult = $this->apply_leave_database->list_leaves();
		if ($leavesResult != false) {
			$data['leavesResult'] = $leavesResult;
		}
		$this->load->view('list_leave',$data);
	}
	
}

?>