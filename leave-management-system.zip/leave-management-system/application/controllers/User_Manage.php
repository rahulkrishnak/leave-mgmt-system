<?php

Class User_Manage extends CI_Controller {
	
	public function __construct() {
		parent::__construct();		
		
		// Load session library
		$this->load->library('session');
		
		// Load database
		$this->load->model('add_user_database');
	}
	
	// Show users list
	public function index() {
		$usersResult = $this->add_user_database->list_users();
		if ($usersResult != false) {
			$data['usersResult'] = $usersResult;
		}
		$this->load->view('user_manage',$data);
	}
	
}

?>