<?php

Class Add_User extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		// Load form helper library
		$this->load->helper('form');
		
		// Load form validation library
		$this->load->library('form_validation');
		
		// Load session library
		$this->load->library('session');
		
		// Load database
		$this->load->model('add_user_database');
	}
	
	// Show add user page
	public function index() {
		$this->load->view('add_user');
	}
	
	// Function to add new user to database
	public function add_user_process() {
		// Check validation for user input
		$this->form_validation->set_rules('username', 'User Name', 'trim|required');
		$this->form_validation->set_rules('userpassword', 'Password', 'trim|required');
		$this->form_validation->set_rules('fullname', 'Full Name', 'trim|required');
		$this->form_validation->set_rules('useremail', 'Email', 'trim|required');
		
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('add_user');
		} 
		else {
			$data = array(
			'user_name' => $this->input->post('username'),
			'user_password' => md5($this->input->post('userpassword')),
			'user_full_name' => $this->input->post('fullname'),
			'user_email' => $this->input->post('useremail'),
			'user_role' => $this->input->post('userrole')
			);
			$result = $this->add_user_database->registration_insert($data);
			if ($result == TRUE) {
				$data['error_message'] = 'User added Successfully !';
				$this->load->view('add_user', $data);
			} else {
				$data['error_message'] = 'Username already exist!';
				$this->load->view('add_user', $data);
			}
		}		
	}
	
	//Function to list users from database
	public function list_user_process() {
	}
	
}

?>