<?php

Class Login extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		// Load form helper library
		$this->load->helper('form');
		
		// Load form validation library
		$this->load->library('form_validation');
		
		// Load session library
		$this->load->library('session');
		
		// Load database
		$this->load->model('login_database');
	}
	
	// Show login page
	public function index() {
		$this->load->view('login');
	}
	
	// User login process
	public function user_login_process() {
		$this->form_validation->set_rules('username', 'User Name', 'trim|required');
		$this->form_validation->set_rules('userpassword', 'Password', 'trim|required');
		
		if ($this->form_validation->run() == FALSE) {
			if(isset($this->session->userdata['logged_in'])){
				$redirUrl = base_url().'index.php/add_user';
				header("location: $redirUrl");
			}else{
				$this->load->view('login');
			}
		} 
		else {
			$data = array(
			'username' => $this->input->post('username'),
			'userpassword' => $this->input->post('userpassword')
			);
			$result = $this->login_database->login($data);
			if ($result == TRUE) {			
				$username = $this->input->post('username');
				$result = $this->login_database->read_user_information($username);
				if ($result != false) {
					$session_data = array(
					'userid' => $result[0]->user_id,
					'userfullname' => $result[0]->user_full_name,
					'useremail' => $result[0]->user_email,
					'userrole' => $result[0]->user_role
					);
					// Add user data in session
					$this->session->set_userdata('logged_in', $session_data);
					
					// Check role and redirect to appropriate pages (If employee redirect to apply leave page, otherwise to add user page)
					if($result[0]->user_role == 3) {
						$redirUrl = base_url().'index.php/apply_leave';
					}
					elseif($result[0]->user_role == 2) {
						$redirUrl = base_url().'index.php/list_leave';
					}
					else {
						$redirUrl = base_url().'index.php/add_user';
					}
					header("location: $redirUrl");		
				}
			} 
			else {
				$data = array(
				'error_message' => 'Invalid Username or Password'
				);
				$this->load->view('login', $data);
			}
		}
	}
	
	// Logout function
	public function logout() {
	
		// Removing session data
		$sess_array = array(
		'userfullname' => '',
		'useremail' => '',
		'userrole' => ''
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$data = array(
		'error_message' => 'Successfully logged out'
		);
		$this->load->view('login', $data);
	}

}

?>