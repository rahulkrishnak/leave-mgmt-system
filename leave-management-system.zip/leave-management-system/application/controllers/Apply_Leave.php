<?php

Class Apply_Leave extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		// Load form helper library
		$this->load->helper('form');
		
		// Load form validation library
		$this->load->library('form_validation');
		
		// Load session library
		$this->load->library('session');
		
		// Load database
		$this->load->model('apply_leave_database');
	}
	
	// Show apply leave page
	public function index() {
		$employeesResult = $this->apply_leave_database->read_employees($this->session->userdata('logged_in')["userid"]);
		if ($employeesResult != false) {
			$data['employeesResult'] = $employeesResult;
		}
		$this->load->view('apply_leave',$data);
	}
	
	// Function to apply leave
	public function apply_leave_process() {
		// Check validation for user input
		$this->form_validation->set_rules('fromDate', 'From', 'trim|required');
		$this->form_validation->set_rules('toDate', 'To', 'trim|required');
		$this->form_validation->set_rules('reason', 'Reason', 'trim|required');
		$this->form_validation->set_rules('backupEmployee', 'Backup Employee', 'trim|required');
		$employeesResult = $this->apply_leave_database->read_employees($this->session->userdata('logged_in')["userid"]);
		if ($employeesResult != false) {
			$data['employeesResult'] = $employeesResult;
		}
		
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('apply_leave',$data);
		} 
		else {
			$data = array(
			'employee_id' => $this->session->userdata('logged_in')["userid"],
			'from_date' => $this->input->post('fromDate'),
			'to_date' => $this->input->post('toDate'),
			'backup_employee_id' => $this->input->post('backupEmployee'),
			'reason' => $this->input->post('reason')
			);
			$result = $this->apply_leave_database->leaves_insert($data);
			if ($result == TRUE) {
				$data['error_message'] = 'Leave applied Successfully !';
				$this->load->view('apply_leave', $data);
			} else {
			}
		}		
	}
	
	//Function to list users from database
	public function list_user_process() {
	}
	
}

?>